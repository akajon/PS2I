//IMPORTS
import React, { Component } from "react";
import { Spring } from "react-spring";
import './App.css';
import ReactDOM from 'react-dom';
import Red from "./images/red.jpg"
import Green from "./images/green.jpg"
import Tank from "./images/tank.jpg"
import axios from "axios"

var response;

class App extends Component {

  componentDidMount() {
    //get data from the Node.js server each second

    setInterval(() => {
      axios.get(`/api/data/get`).then(res =>{
        response = res.data;
        ReactDOM.render(
          this.render(response['timeStamp'], response['pumpsState'], response['waterLevel']),
          document.getElementById('root'));
    })
    }, 1000);
  }

  render(time, pumps, water) {
    let first = Red
    let second = Red
    let third = Red
    let fourth = Red

    if (pumps & 1) {first = Green}
    if (pumps & 2) {second = Green}
    if (pumps & 4) {third = Green}
    if (pumps & 8) {fourth = Green}

    const project = () => {
      // Use field from api (the one with liters/100)
      
      return <div>
        <div id="container">
          <div id="infoi">
            <Spring from={{ percent: 0 }} to={{ percent: 100 }}>
              {() => (
                <div className="progress vertical">
                  <div style={{ height: `${water}%` }} className="progress-bar">
                    <span className="sr-only">{`${water}`}</span>
                  </div>
                </div>
              )}
            </Spring>
          </div>
          <div id="navi">
            <img src={Tank} alt="tank" height="400" className="center"/>
          </div>
        </div>
        <div className="top">
          <table>
            <tr>
              <td>
                <img src={fourth} alt="fourth button"/>
              </td>
              <td>
                <img src={third} alt="third button"/>
              </td>
              <td>
                <img src={second} alt="second button"/>
              </td>
              <td>
                <img src={first} alt="first button"/>
              </td>
            </tr>
          </table>
        </div>
      </div>
    }
      
    return (
        <div style={{ textAlign: "left" }}>
          {time
            ? <p>
              Byte value is: {JSON.stringify(response)}
              {project()}
            </p>
            : <p>Loading...</p>}
        </div>
    );
  }
}

export default App;
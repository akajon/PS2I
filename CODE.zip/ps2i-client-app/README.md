# proiect-sincretic2

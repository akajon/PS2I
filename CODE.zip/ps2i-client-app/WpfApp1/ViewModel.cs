﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace PS2
{
    class ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        void OnPropertyChanged(string prop)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        private bool _s1;
        private bool _s2;
        private bool _s3;
        private bool _s4;
        private int _pumpsState;
        private int _automateMode;

        public bool S1
        {
            get { return _s1; }
            set
            {
                _s1 = value;
                OnPropertyChanged(nameof(S1Visibility));
                OnPropertyChanged(nameof(S1Color));
            }
        }
        public bool S2
        {
            get { return _s2; }
            set
            {
                _s2 = value;
                OnPropertyChanged(nameof(S2Visibility));
                OnPropertyChanged(nameof(S2Color));
            }
        }
        public bool S3
        {
            get { return _s3; }
            set
            {
                _s3 = value;
                OnPropertyChanged(nameof(S3Visibility));
                OnPropertyChanged(nameof(S3Color));
            }
        }
        public bool S4
        {
            get { return _s4; }
            set
            {
                _s4 = value;
                OnPropertyChanged(nameof(S4Visibility));
                OnPropertyChanged(nameof(S4Color));
            }
        }
        public int PumpsState
        {
            get { return Convert.ToInt32(S1) << 3 | Convert.ToInt32(S2) << 2 | Convert.ToInt32(S3) << 1 | Convert.ToInt32(S4); }
            set
            {
                _pumpsState = value;
                S1 = Convert.ToBoolean(value >> 3 & 1);
                S2 = Convert.ToBoolean(value >> 2 & 1);
                S3 = Convert.ToBoolean(value >> 1 & 1);
                S4 = Convert.ToBoolean(value >> 0 & 1);
            }
        }
        public System.Windows.Visibility S1Visibility
        {
            get
            {
                if (_s1)
                    return System.Windows.Visibility.Visible;
                else 
                    return System.Windows.Visibility.Hidden;
            }
        }
        public System.Windows.Visibility S2Visibility
        {
            get
            {
                if (_s2)
                    return System.Windows.Visibility.Visible;
                else
                    return System.Windows.Visibility.Hidden;
            }
        }
        public System.Windows.Visibility S3Visibility
        {
            get
            {
                if (_s3)
                    return System.Windows.Visibility.Visible;
                else
                    return System.Windows.Visibility.Hidden;
            }
        }
        public System.Windows.Visibility S4Visibility
        {
            get
            {
                if (_s4)
                    return System.Windows.Visibility.Visible;
                else
                    return System.Windows.Visibility.Hidden;
            }
        }

        public System.Windows.Media.Brush S1Color
        {
            get { return _s1 ? Brushes.Green : Brushes.Red; }
        }
        public System.Windows.Media.Brush S2Color
        {
            get { return _s2 ? Brushes.Green : Brushes.Red; }
        }
        public System.Windows.Media.Brush S3Color
        {
            get { return _s3 ? Brushes.Green : Brushes.Red; }
        }
        public System.Windows.Media.Brush S4Color
        {
            get { return _s4 ? Brushes.Green : Brushes.Red; }
        }

        public int AutomateMode
        {
            set 
            {
                _automateMode = value;
                OnPropertyChanged(nameof(S5Color));
                Console.WriteLine(_automateMode);

            }
            get { return _automateMode; }
        }
        public System.Windows.Media.Brush S5Color
        {
            get { return _automateMode == 1 ? Brushes.LightGreen : Brushes.IndianRed; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PS2
{
    public class Stamp
    {
        public Stamp(DateTime WhenWasThat, int pumpStates, int currentLevel)
        {
            TimeStamp = WhenWasThat;
            PumpsState = pumpStates;
            WaterLevel = currentLevel;
        }

        public Stamp() { }

        public DateTime TimeStamp { get; set; }
        public int PumpsState { get; set; }
        public int WaterLevel { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PS2;
using Newtonsoft.Json;
using System.Media;

namespace PS2
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        ViewModel _viewModel;
        private System.Windows.Threading.DispatcherTimer _timer = new System.Windows.Threading.DispatcherTimer();
        private const int _unit = 1;
        private static readonly HttpClient client = new HttpClient();
        private int _openPumpsNumber = -1;

        public UserControl1()
        {
            InitializeComponent();
            _viewModel = new ViewModel();
            this.DataContext = _viewModel;
            progressBar.Value = 50;
            _timer.Interval = System.TimeSpan.FromMilliseconds(600);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            GetProgressBarColor();
            if (_viewModel.S1) progressBar.Value += 1;
            if (_viewModel.S2) progressBar.Value += 1;
            if (_viewModel.S3) progressBar.Value += 1;
            if (_viewModel.S4) progressBar.Value += 1;
            progressBar.Value -= 2;

            Console.WriteLine("pump states: " + _viewModel.PumpsState);
            Console.WriteLine("automate mode: " + _viewModel.AutomateMode);
            try
            {
                PutData(new Stamp(DateTime.Now, _viewModel.PumpsState, Convert.ToInt32(progressBar.Value)));
            }
            catch (Exception ex)
            { Console.WriteLine(ex.ToString()); }
            if (_viewModel.AutomateMode == 1)
            {
                if (progressBar.Value > 80)
                    closePumps();
                else if (progressBar.Value < 20)
                    openPumps();
            }
            if (progressBar.Value > 80)
                SystemSounds.Asterisk.Play();

        }

        private void updateNumberOfOpenPumps()
        {
            int count = 0;
            int pumpState = _viewModel.PumpsState;

            while (pumpState != 0)
            {
                count += ((pumpState & 1) == 1) ? 1 : 0;
                pumpState >>= 1;
            }
            _openPumpsNumber = count;
        }

        private void openPumps()
        {
            updateNumberOfOpenPumps();

            if (_openPumpsNumber < 5)
            {
                int pumpState = _viewModel.PumpsState;
                int numberOfBit = 0;

                // get the first bit with 0 (first pump deactivated)
                while ((pumpState & 1) != 0) 
                { 
                    pumpState >>= 1; 
                    numberOfBit++; 
                }
                _viewModel.PumpsState |= 1 << numberOfBit;

            }

        }


        private void closePumps()
        {
            updateNumberOfOpenPumps();

            if (_openPumpsNumber > 0)
            {
                int pumpState = _viewModel.PumpsState;
                int numberOfBit = 0;

                // get the first bit with 1 (first pump activated)
                while ((pumpState & 1) != 1)
                {
                    pumpState >>= 1;
                    numberOfBit++;
                }
                _viewModel.PumpsState &= ~(1 << numberOfBit);

            }
        }

        public async static void PutData(Stamp PostData)
        {
            try
            {
                // Create a request using a URL that can receive a post.   
                WebRequest request = WebRequest.Create("https://ps2i-web-api.azurewebsites.net/api/data/post");
                // Set the Method property of the request to POST.  
                request.Method = "POST";

                // Create POST data and convert it to a byte array.  
                string postData = JsonConvert.SerializeObject(PostData);
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);

                // Set the ContentType property of the WebRequest.  
                request.ContentType = "application/json";
                // Set the ContentLength property of the WebRequest.  
                request.ContentLength = byteArray.Length;

                // Get the request stream.  
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.  
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.  
                dataStream.Close();

                // Get the response.  
                WebResponse response = request.GetResponse();
                // Display the status.  
                Console.WriteLine("Status Description: " + ((HttpWebResponse)response).StatusDescription);

                // Get the stream containing content returned by the server.  
                // The using block ensures the stream is automatically closed.
                using (dataStream = response.GetResponseStream())
                {
                    // Open the stream using a StreamReader for easy access.  
                    StreamReader reader = new StreamReader(dataStream);
                    // Read the content.  
                    string responseFromServer = reader.ReadToEnd();
                    // Display the content.  
                    Console.WriteLine("Response from Server: " + responseFromServer);
                }

                // Close the response.  
                response.Close();
            }
            catch (Exception ex) { }
        }

        private void GetProgressBarColor()
        {
            if (progressBar.Value >= 0 && progressBar.Value <= 70)
            { progressBar.Foreground = new SolidColorBrush(Color.FromRgb(0, 255, 0)); return; }
            if (progressBar.Value > 70 && progressBar.Value < 90)
            { progressBar.Foreground = new SolidColorBrush(Color.FromRgb(0, 0, 255)); return; }
            if (progressBar.Value > 90)
            { progressBar.Foreground = new SolidColorBrush(Color.FromRgb(255, 0, 0)); return; }
        }

        private void Button_Click_S1(object sender, RoutedEventArgs e)
        {
            _viewModel.S1 = !_viewModel.S1;
        }

        private void Button_Click_S2(object sender, RoutedEventArgs e)
        {
            _viewModel.S2 = !_viewModel.S2;

        }
        private void Button_Click_S3(object sender, RoutedEventArgs e)
        {
            _viewModel.S3 = !_viewModel.S3;
        }

        private void Button_Click_S4(object sender, RoutedEventArgs e)
        {
            _viewModel.S4 = !_viewModel.S4;
        }

        private void Button_Click_S_All(object sender, RoutedEventArgs e)
        {
            if ((_viewModel.S1 || _viewModel.S2 || _viewModel.S3 || _viewModel.S4)
                && !(_viewModel.S1 && _viewModel.S2 && _viewModel.S3 && _viewModel.S4))
            {
                _viewModel.PumpsState = 0;
                return;
            }
            _viewModel.PumpsState ^= 15;
            //_viewModel.S1 = !_viewModel.S1;
            //_viewModel.S2 = !_viewModel.S2;
            //_viewModel.S3 = !_viewModel.S3;
            //_viewModel.S4 = !_viewModel.S4;
        }

        private void Button_Click_S_Automate(object sender, RoutedEventArgs e)
        {
            _viewModel.AutomateMode ^= 1;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ps2i_web_api
{
    public class ProcessData
    {
        public string timeStamp { get; set; }
        public int pumpsState { get; set; }
        public int waterLevel { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ps2i_web_api.Controllers
{
    [Produces("application/json")]
    [Route("api/data")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class mainController : ControllerBase
    {
        [HttpPost]
        [Route("post")]
        public void postData([FromBody] ProcessData value)
        {
            Console.WriteLine("Got new values:\n\tTimeStamp -> "+ value.timeStamp
                + "\n\tpumpsState -> " + value.pumpsState
                + "\n\twaterLevel -> " + value.waterLevel);
            Program.processData = value;
        }

        [HttpGet]
        [Route("get")]
        public ProcessData getData()
        {
            return Program.processData;
        }
    }
}
